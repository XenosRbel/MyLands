# Ashen Crowns — Resource Pack v0.1.0

This is an original starter asset pack based on the supplied `ART_PROMPTS.md` brief.
It is a new fantasy setting. It does not contain My Lands screenshots, sprites, logos, names, or extracted game files.

## Included

- 7 resource icons: timber, grain, stone, iron, gold, lore, starglass.
- 11 prompted item icons plus 2 auxiliary icons.
- 22 isometric building sprites.
- 12 unit portrait sprites.
- 4 hero portrait sprites.
- 8 terrain tile illustrations.
- UI atlas plus 11 approximate component crops.
- Original generated source sheets for manual art direction and recropping.
- `pack.json` manifest and original user-supplied art prompt document.

## Integration layout

All game assets are under `packs/ashen-crowns/assets/`.
IDs are derived from the supplied art prompt. Check `pack.json` for asset paths.

## Important production notes

1. This is a visual starter pack, not a fully production-ready atlas.
2. Resource/item icons retain some dark background pixels because their generated source sheet used a dark backing. Verify alpha edges before shipping.
3. Building sprites have magenta keying removed and transparent backgrounds. Inspect edge halos at 1x and 2x scale.
4. Portraits are square card portraits, not animated unit sprites.
5. Terrain illustrations are static square tiles. They are not guaranteed mathematically seamless.
6. UI component crops are approximate. Use `ui_atlas.png` as the master reference and refine 9-slice insets manually.
7. Missing unit concepts from the brief (wagon, settler, wolf, brigand, troll, wraith, golem, drake), neutral map objects, race emblems, city markers, and background art are not generated in v0.1.
8. Building upgrade variants (levels 1/10/20), animations, mobile resolutions, and accessibility states are not included.

## Provenance

Generated in ChatGPT using OpenAI Image Generation on 2026-10-31 from the supplied Ashen Crowns art brief. This manifest records provenance; it is not a legal opinion or warranty. Confirm current tool terms, applicable licenses, and marketplace requirements before commercial distribution.
