# Asset gap report — v0.1.0

## Generated in this pack
- Resources: 7/7
- Prompted items: 11/11
- Buildings: 22/22
- Units: 12/22 (the first twelve core/faction portraits)
- Heroes: 4/4
- Terrain: 8/8
- UI: master atlas + approximate crops

## Not generated yet
- Units: wagon, settler, wolf, brigand, troll, wraith, golem, drake.
- Neutrals: wolf_den, brigand_camp, barrow, crater.
- Emblems: thornkin, ironvow, ashborn, gravewarden, dawnpact, duskbound.
- Player-city markers in race colors.
- Login and city backgrounds.
- Standalone resource bar slots, tooltip, progress bar, and true 9-slice exports.
- Sprite animations, battle effects, map overlays, selected/hover/disabled states.

## Technical validation still required
- Inspect icon alpha and edge artifacts.
- Confirm consistent isometric ground plane and sprite scale.
- Establish logical sprite anchor points and collision bounds.
- Verify readability at target sizes (24px icons, 128–256px UI, 512px building cards).
- Add WebP/AVIF variants where the client pipeline benefits.
- Check every image's metadata and optimize final production binaries.
