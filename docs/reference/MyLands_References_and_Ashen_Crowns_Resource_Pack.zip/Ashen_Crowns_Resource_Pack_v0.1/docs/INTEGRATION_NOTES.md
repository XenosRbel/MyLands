# Integration notes

`packs/ashen-crowns/pack.json` is a generated asset manifest for this delivery. It records IDs, relative paths, format, file sizes, visual theme, and provenance.

It is intentionally conservative: do not assume it already conforms to the final game-engine schema until the engine's Game Pack loader is implemented or its schema is available. Map the manifest into the engine's canonical `theme.icons`, building, unit, hero, and terrain registries during integration.

All asset paths are relative to `packs/ashen-crowns/`. The manifest paths begin with `assets/`. Preserve the source sheets for future recropping.
