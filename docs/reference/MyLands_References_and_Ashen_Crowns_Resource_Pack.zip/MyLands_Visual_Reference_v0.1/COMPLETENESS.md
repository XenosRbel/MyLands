# Completeness and limitations

This is a first-pass public visual reference collection, not a full extraction of every original game screen.

- 12 public screenshot/image references are catalogued.
- The official encyclopedia exposes a much larger system taxonomy than public screenshot galleries show.
- Market, auction, alliance, hero detail, mission report, mail, settings, tutorial, and several domain types do not have sufficiently clear standalone screenshots in this archive.
- Several sources are third-party galleries or portfolios. Confirm rights and source conditions before redistributing or using images outside private analysis.
- The current runtime could not download remote image binaries. Therefore the ZIP includes a local HTML gallery with remote image URLs, source pages, captions, and a detailed screen inventory, rather than local copies of the copyrighted screenshots.
- The original game client may expose additional context menus, popups, hover states, and modal variants. Those require direct capture from a lawful running client.
