# Official encyclopedia map

The official My Lands encyclopedia identifies these systems and screen families:

- Rules and quick preview
- Races
- City and villages
- Resources, Black Gems, population
- Buildings, Gate, Market, Auction
- Army, unit descriptions and parameters
- Sciences, specialisations, alchemy
- Kingdom
- Outer domains: Pits, Mines, Salt Lake, Grail
- Dungeon and underground domains: Barracks, Tomb, Sarcophagus, Acropolis
- Ruins, Stonehenge, Ancients' Defence
- Combat missions: ranks, ratings, factions, joint attack, assistance, battle, battle calculator
- Hero missions: encamping, domain destruction, hero release
- Non-combat missions: espionage, exploration, city foundation, observation, resources transportation, troops relocation
- Heroes, classes, skills, passive abilities, spells, artifacts, scrolls, mana bottles
- Alliances, clans, clan castles, mentorship, tournaments, random events, quests, messaging

The official overview describes founding cities, studying sciences, constructing/upgrading buildings, training troops, hiring heroes, market trading, exploring ruins/pits/salt lakes/mines, defeating monsters, seizing outer domains, spying, village conflict, building destruction/repair, and alliances.

Sources:
- Official encyclopedia: https://www.mlgame.us/wiki
- Official building taxonomy: https://us.mlgame.org/wiki-us/Wiki.jsp?page=Buildings
- Official Steam store: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Steam Community: https://steamcommunity.com/app/290730
