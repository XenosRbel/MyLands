# My Lands Visual Reference Archive v0.1

Open `index.html` in a browser with internet access to view the 12 linked screenshot references.

Files:
- `index.html` — visual gallery loading public images from source URLs.
- `SOURCES.md` — exact image and page URLs with notes.
- `SCREEN_CATALOG.md` — coverage inventory, evidence level and missing screens.
- `OFFICIAL_SYSTEMS_INDEX.md` — taxonomy based on the official encyclopedia.
- `COMPLETENESS.md` — limitations and remaining capture work.

This archive is for research and interface analysis. It is not a redistribution of original game assets.
