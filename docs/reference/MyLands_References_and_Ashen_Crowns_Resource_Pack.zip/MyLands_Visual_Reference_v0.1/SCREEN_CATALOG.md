# Screen catalogue — My Lands: Black Gem Hunting

Status labels:
- **VISUAL FOUND** — a public screenshot reference is listed in this archive.
- **DOCUMENTED** — the official encyclopedia describes the feature, but this archive has no verified screenshot of the full screen.
- **CAPTURE NEEDED** — the complete UI/state still requires a live-client capture or a reliable walkthrough.

## Screens and panels

| Area | Status | Reference IDs / notes |
|---|---|---|
| Global HUD / top resources | VISUAL FOUND | ML-001, ML-003, ML-005, ML-006, ML-007 |
| City view / hex cell layout | VISUAL FOUND | ML-002, ML-004, ML-007 |
| Building catalogue / construction modal | VISUAL FOUND | ML-005, ML-008 |
| Outer domains: Salt Lake | VISUAL FOUND | ML-001 |
| Outer domains: Stone Mine | VISUAL FOUND | ML-003 |
| Hostile / Evil Residence | VISUAL FOUND | ML-006 |
| Research tree | VISUAL FOUND | ML-009 |
| Inventory and items | VISUAL FOUND | ML-010 |
| Spellbook | VISUAL FOUND | ML-011 |
| Tactical battle / hex battlefield | VISUAL FOUND | ML-012 |
| Race-specific building appearances | DOCUMENTED | Official Buildings encyclopedia says building types differ by race; capture each race and level separately. |
| Resources / Black Gems | DOCUMENTED | Official encyclopedia. |
| Population / workers / builders | DOCUMENTED | Official encyclopedia and construction screenshot. |
| Army / unit parameters | DOCUMENTED | Official encyclopedia; screenshots of all unit lists and detail modals needed. |
| Kingdom / world map | DOCUMENTED | Screens show isolated map/domain scenes; comprehensive kingdom-map screen still needed. |
| Villages | DOCUMENTED | Official encyclopedia. |
| Mines / Pits / Salt Lakes / Grail | DOCUMENTED | ML-001 and ML-003 cover two types; remaining screens need capture. |
| Ruins / monsters | DOCUMENTED | Official encyclopedia; visual detail and spy report screens needed. |
| Underground domains | DOCUMENTED | Official encyclopedia; full panel captures needed. |
| Market / trade | DOCUMENTED | Official encyclopedia; order book, exchange form, confirmation and history screens needed. |
| Auction | DOCUMENTED | Official encyclopedia; bid, lot, filters and history screens needed. |
| Alliances / clans / diplomacy | DOCUMENTED | Official encyclopedia; member list, roles, diplomacy and clan castle screens needed. |
| Missions / exploration / espionage | DOCUMENTED | Official encyclopedia; mission setup, timers, reports and result panels needed. |
| Heroes / equipment / skills | DOCUMENTED | Official encyclopedia; hero roster, profile, equipment, skill tree, mission setup and report needed. |
| Quests / mail / notifications | DOCUMENTED | Official encyclopedia lists quests and messaging; screen captures needed. |
| Rankings / ratings / factions | DOCUMENTED | Official encyclopedia; ranking tables, filters and profile drill-downs needed. |
| Settings / tutorial / onboarding | CAPTURE NEEDED | No sufficiently clear public screen found in this collection. |

## Implementation guidance

Do not copy the original UI pixel-for-pixel. Use this catalogue to understand information hierarchy, navigation, density, and interaction states. Build a distinct UI system for Ashen Crowns with original assets and terminology.
