# Sources and image references

The archive contains annotated references and direct image links. Image files are not locally mirrored because the runtime could not retrieve the external image binaries. The gallery loads the original image URLs when opened with internet access.

## ML-001 — Salt Lake / floating outer domain
- Category: Outer domains
- Publisher: GameGuru
- Image: https://gameguru.ru/clf/7d/29/c9/38/articles.0a4a12d2d571a931.png
- Source page: https://gameguru.ru/publication/obzor_my_lands_black_gem_hunting/
- Visual notes: Floating island / Salt Lake environment, resource bar, domain construction timers.

## ML-002 — City interface / fortified settlement
- Category: City
- Publisher: Behance portfolio
- Image: https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/8752ac44885387.56078cf41efda.jpg
- Source page: https://www.behance.net/gallery/5721541/Art-for-browser-game-My-Lands
- Visual notes: Isometric city, hexagonal perimeter, production buildings and bottom action bar.

## ML-003 — Stone Mine / underground domain
- Category: Outer domains
- Publisher: Steam store
- Image: https://cdn.akamai.steamstatic.com/steam/apps/290730/ss_53ee7b19b1fa33b50c12c28ab0ce08cf42b572b3.1920x1080.jpg
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Spiral mine, transport rails, timers, resource HUD and army bar.

## ML-004 — City / dark biome hex grid
- Category: City / map
- Publisher: PlayMMORTS
- Image: https://cdn.nichesites.pikoya.com/playmmorts_com/images/games/10734/gallery/32329.jpg
- Source page: https://www.playmmorts.com/games/my_lands_black_gem_hunting
- Visual notes: Hex-grid city cells, numbered plots, walls, resource nodes and unit strip.

## ML-005 — Building construction menu
- Category: Buildings
- Publisher: Softpedia
- Image: https://games-cdn.softpedia.com/screenshots/my-lands-black-gem-hunting_3.jpg
- Source page: https://games.softpedia.com/get/free-to-play/My-Lands-Black-Gem-Hunting.shtml
- Visual notes: Building category tabs, building selection, costs, builder count, Construct/Cancel.

## ML-006 — Evil Residence / outer domain
- Category: Outer domains
- Publisher: Steam store
- Image: https://cdn.akamai.steamstatic.com/steam/apps/290730/ss_6fd4dbe4c07959d2130f950c7ae4aefee6cf0aaa.1920x1080.jpg?t=1447361051
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Hostile residence on world map; resource HUD and troop strip.

## ML-007 — City / developed settlement
- Category: City
- Publisher: Steam store
- Image: https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/290730/ss_7494444992311e6fd07238459ba106171744e568.1920x1080.jpg?t=1447361051
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Developed city in a green biome, production structures, bottom actions and troops.

## ML-008 — Construction catalogue / race building set
- Category: Buildings
- Publisher: Steam store
- Image: https://cdn.akamai.steamstatic.com/steam/apps/290730/ss_a6f5951bd9f2f82a26f10d7c733ca4451ca93c27.1920x1080.jpg?t=1447361051
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Tabs: Producing, Municipal, Military, Special, Defensive; selected building requirements.

## ML-009 — Research tree
- Category: Sciences
- Publisher: Steam store
- Image: https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/290730/ss_7fd489353b52c1ff006af97340b652cbca85c70f.1920x1080.jpg?t=1447361051
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Connected technology nodes, current research, research rate, progress and prerequisites.

## ML-010 — Inventory / items
- Category: Inventory
- Publisher: Steam store
- Image: https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/290730/ss_be0ca4424555274e4df290a9a1f7a3a3eb6fa45e.1920x1080.jpg?t=1447361051
- Source page: https://store.steampowered.com/app/290730/My_Lands_Black_Gem_Hunting/
- Visual notes: Two-pane inventory, item grid, selected item area, pagination and premium currency.

## ML-011 — Spellbook / spell selection
- Category: Heroes and magic
- Publisher: RAWG
- Image: https://media.rawg.io/media/resize/640/-/screenshots/63d/63d87a5b3616292b1bb741d576311a6a.jpg
- Source page: https://rawg.io/games/my-lands-black-gem-hunting
- Visual notes: Book-style spell catalogue, spell icons, levels and costs.

## ML-012 — Tactical battle / hex battlefield
- Category: Battles
- Publisher: RAWG
- Image: https://media.rawg.io/media/resize/640/-/screenshots/89c/89c9410733cb02bab76f6e168ecd9262.jpg
- Source page: https://rawg.io/games/my-lands-black-gem-hunting
- Visual notes: Hex grid, combat units, health bars, obstacles and round/turn status.
